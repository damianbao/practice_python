import os



def what_is_next():
    for f in os.listdir():
        f1=open (f, 'r')
        f1.readline(


what_is_next()
