# -*- coding: utf-8 -*-
"""
Created on Thu Apr 19 22:12:47 2018

@author: staie
"""
import os
os.chdir('Adventure_Time')


f= open(the_simulator, 'r')

