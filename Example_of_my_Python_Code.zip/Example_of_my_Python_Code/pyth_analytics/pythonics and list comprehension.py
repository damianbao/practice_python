x = ['2', '3', '4']

y = []

for xx in x:
    y.append(float(xx))

print (y)

z = [float (xx) for xx in x]

print(z)
