# -*- coding: utf-8 -*-
"""
Created on Tue Apr 17 15:09:00 2018

@author: staie
"""

s1 = 'Look, I guarantee there`ll be'
s2 = ' times. I guarantee that at some '
s3 = ', '
s4 = ' or both of us is gonna want to get out of this '
s5 = '. But I also guarantee that if I don`t ask you to be'
s6 = ", I'll "
s7 = 'it for the rest of my '
s8 = ', because I know, in my '
s9 = ", you're the "
s10 = 'one for me.'

print ('Please enter a word as indicated. Hilarity will ensue...')

lib1 = input ('adjective ')
lib2 = input ('event ')
lib3 = input ('amount ')
lib4 = input ('noun ')
lib5 = input ('adjective ')
lib6 = input ('action verb ')
lib7 = input ('noun ')
lib8 = input ('body part')
lib9 = input ('adjective ')
 
print ()
answer = print (s1,lib1,s2,lib2,s3,lib3,s4,lib4,s5,lib5,s6,lib6,s7,lib7,s8,lib8,s9,lib9,s10)